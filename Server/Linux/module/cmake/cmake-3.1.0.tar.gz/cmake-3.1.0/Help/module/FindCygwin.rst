.. cmake-module:: ../../Modules/FindCygwin.cmake
