.. cmake-module:: ../../Modules/FindSWIG.cmake
