.. cmake-module:: ../../Modules/CMakeFindDependencyMacro.cmake
