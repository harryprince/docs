.. cmake-module:: ../../Modules/FindosgQt.cmake
