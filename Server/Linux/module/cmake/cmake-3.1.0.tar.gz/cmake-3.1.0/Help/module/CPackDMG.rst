.. cmake-module:: ../../Modules/CPackDMG.cmake
